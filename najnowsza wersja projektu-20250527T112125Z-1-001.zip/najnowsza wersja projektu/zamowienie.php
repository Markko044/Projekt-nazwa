<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Formularz zamówienia</title>
    <style>
        body {
            background-color: #332d2d;
            color: white;
            font-family: 'Trebuchet MS', sans-serif;
            padding: 20px;
            text-align: center;
        }
        form {
            max-width: 500px;
            margin: auto;
            background-color: #2b2626;
            padding: 20px;
            border-radius: 10px;
            border: 3px solid salmon;
            text-align: left;
        }
        label {
            display: block;
            margin-top: 15px;
        }
        input[type="text"], select {
            width: calc(100% - 16px);
            padding: 8px;
            margin-top: 5px;
            border-radius: 5px;
            border: none;
            text-align: center;
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
        .radio-group {
            margin-top: 10px;
        }
        .radio-group label {
            display: inline-block;
            margin-right: 10px;
        }
        button {
            background-color: salmon;
            border: none;
            padding: 10px 20px;
            margin-top: 20px;
            border-radius: 5px;
            cursor: pointer;
        }
        .message {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            text-align: center;
        }
    </style>
    <script>
        function updatePaymentOptions() {
            var deliveryType = document.querySelector('input[name="dostawa"]:checked')?.value;
            document.getElementById('wPizzerii').style.display = (deliveryType === 'dowóz') ? 'none' : 'inline-block';
            document.getElementById('przyDrzwiach').style.display = (deliveryType === 'odbiór') ? 'none' : 'inline-block';
        }
    </script>
</head>
<body>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    echo '<div class="message">Zamówienie zostało złożone!</div>';
}
?>

<form method="post" action="">
    <input type="hidden" name="submit" value="1">

    <label>Miasto:
        <input type="text" name="miasto" required>
    </label>
    <label>Ulica i nr domu:
        <input type="text" name="ulica" required>
    </label>

    <label>Sposób dostawy:</label>
    <div class="radio-group" onchange="updatePaymentOptions()">
        <label><input type="radio" name="dostawa" value="dowóz" required> Dowóz</label>
        <label><input type="radio" name="dostawa" value="odbiór"> Odbiór</label>
        <label><input type="radio" name="dostawa" value="na miejscu"> Na miejscu</label>
    </div>

    <label>Sposób płatności:</label>
    <div class="radio-group">
        <label id="przyDrzwiach"><input type="radio" name="platnosc" value="przy drzwiach" required> Przy drzwiach</label>
        <label id="wPizzerii"><input type="radio" name="platnosc" value="w pizzerii"> W pizzerii</label>
        <label><input type="radio" name="platnosc" value="przez internet"> Przez internet</label>
    </div>

    <button type="submit">Złóż zamówienie</button>
</form>

</body>
</html>
