<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Formularz zamówienia</title>
    <style>
        body {
            background-color: #332d2d;
            color: white;
            font-family: 'Trebuchet MS', sans-serif;
            padding: 20px;
            text-align: center;
        }
        form {
            max-width: 500px;
            margin: auto;
            background-color: #2b2626;
            padding: 20px;
            border-radius: 10px;
            border: 3px solid salmon;
            text-align: left;
        }
        .lejbel{
            margin:auto;
            display:flex;
            align-items:center;
            justify-content:center;
            margin-top: 15px;     
        }
       
        input[type="text"], select {
            width: calc(100% - 16px);
            padding: 8px;
            margin-top: 5px;
            border-radius: 5px;
            border: none;
            text-align: center;
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
        .radio-group {
            margin-top: 10px;
            margin:auto;
            display:flex;
            align-items:center;
            justify-content:center;
            margin-left: auto;
            margin-right: auto;
            

        }
        .radio-group label {
            display: inline-block;
            margin-right: 10px;
        }
        .baton {
            background-color: salmon;
            border: 1px solid black;
            padding: 10px 20px;
            margin-top: 20px;
            border-radius: 5px;
            display:flex;
            justify-content:center;
            align-items:center;
            margin:auto;
            cursor: pointer;
            transition: all 0.3s;
        }
        .baton:hover{
    transform: translateY(-5px);
    box-shadow: 0px 4px 6px black;

}
.baton:active{
    transform:translateY(2px);
}
        .message {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            text-align: center;
        }
        .ulica{
            justify-content:center;
            text-align: center;
            align-items:center;
            margin:auto;
            padding:4px;
        }
        .dih{
            padding:5px;
            margin-top:10px;
        }
    </style>
    <script>
        function updatePaymentOptions() {
            var deliveryType = document.querySelector('input[name="dostawa"]:checked')?.value;
            document.getElementById('wPizzerii').style.display = (deliveryType === 'dowóz') ? 'none' : 'inline-block';
            document.getElementById('przyDrzwiach').style.display = (deliveryType === 'odbiór') ? 'none' : 'inline-block';
        }
    </script>
</head>
<body>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    echo '<div class="message">Zamówienie zostało złożone!</div>';
}
?>

<form method="post" action="">
    <input type="hidden" class="ulica" name="submit" value="1">

    <h3 class="ulica">Miasto:</h3>
    <input type="text" class="ulica" name="miasto" required>

    <h3 class="ulica">Ulica i nr domu:</h3>
    <input type="text" name="ulica" required>

    <label class="lejbel" >Sposób dostawy:</label>
    <div class="radio-group" onchange="updatePaymentOptions()">
        <label><input type="radio" name="dostawa" value="dowóz" required> Dowóz</label>
        <label><input type="radio" name="dostawa" value="odbiór"> Odbiór</label>
        <label><input type="radio" name="dostawa" value="na miejscu"> Na miejscu</label>
    </div>

    <label class="lejbel">Sposób płatności:</label>
    <div class="radio-group">
        <label id="przyDrzwiach"><input type="radio" name="platnosc" value="przy drzwiach" required> Przy drzwiach</label>
        <label id="wPizzerii"><input type="radio" name="platnosc" value="w pizzerii"> W pizzerii</label>
        <label><input type="radio" name="platnosc" value="przez internet"> Przez internet</label>
    </div>
<div class="dih">
    <button type="submit" class="baton">Złóż zamówienie</button>
</div>
</form>

</body>
</html>
